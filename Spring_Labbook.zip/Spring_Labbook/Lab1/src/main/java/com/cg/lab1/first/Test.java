package com.cg.lab1.first;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext con=new ClassPathXmlApplicationContext("spring1.xml");
		Employee emp=con.getBean("emp",Employee.class);
		System.out.println("Employee Details");
		System.out.println("-------------------------");
		System.out.println("EmployeeId : "+emp.getEmployeeId());
		System.out.println("Employee Name : "+emp.getEmployeeName());
		System.out.println("Employee Salary : "+emp.getSalary());
		System.out.println("Employee BU :  "+emp.getBusinessUnit());
		System.out.println("Age: "+emp.getAge());
	}
}
