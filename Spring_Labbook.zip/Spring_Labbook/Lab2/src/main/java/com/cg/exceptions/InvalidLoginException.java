package com.cg.exceptions;

public class InvalidLoginException extends RuntimeException {

    public InvalidLoginException(String arg0) {
        super(arg0);
        System.err.println(arg0);
        // TODO Auto-generated constructor stub
    }

}